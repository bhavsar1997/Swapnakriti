import React, { Component } from 'react';
import NavBar from '../components/NavBar';
import BrandLogoSlider from '../components/BrandLogoSlider';
import Footer from '../components/Footer';
import MobileMenu from '../components/MobileMenu';
import { connect } from 'react-redux';
import { getServicesData } from '../actions';
class Services extends Component {

    componentDidMount() {
        const { getServicesData } = this.props;
        getServicesData();
    }

    render() {
        let Datalist;

        if (this.props.finalData && this.props.finalData.length && this.props.loading === false) {
            Datalist = this.props.finalData.map((val, i) => {
                return (
                    <div className="col-lg-4 col-md-6 col-12 section-space--bottom--30" key={i}>
                        <div className="service-grid-item">
                            <div className="service-grid-item__image">
                                <div className="service-grid-item__image-wrapper">
                                    <a href={`/${val.pageLink}`}>
                                        <img src={`assets/img/service/${val.img}`} className="img-fluid" alt="Service Grid" />
                                    </a>
                                </div>
                                <div className="icon">
                                    <i className={val.iconClass} />
                                </div>
                            </div>
                            <div className="service-grid-item__content">
                                <h3 className="title">
                                    <a href={`/${val.pageLink}`}>{val.serviceTitle}</a>
                                </h3>
                                <p className="subtitle">{val.serviceSubtitle}</p>
                                <a href={`/${val.pageLink}`} className="see-more-link">SEE MORE</a>
                            </div>
                        </div>
                    </div>
                )
            });
        }
        else {
            Datalist=""
        }

        return (
            <div>

                {/* Navigation bar */}
                {/* <NavBar /> */}

                {/* breadcrumb */}
                {/*====================  breadcrumb area ====================*/}
                <div className="breadcrumb-area breadcrumb-bg">
                    <div className="container">
                        <div className="row">
                            <div className="col">
                                <div className="page-banner text-center">
                                    <h1>Service</h1>
                                    <ul className="page-breadcrumb">
                                        <li><a href="/">Home</a></li>
                                        <li>Service</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/*====================  End of breadcrumb area  ====================*/}

                {/*====================  service page content ====================*/}
                <div className="page-wrapper section-space--inner--120">
                    {/*Service section start*/}
                    <div className="service-section">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-12">
                                    <div className="service-item-wrapper">
                                        <div className="row">
                                            {Datalist}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Service section end*/}
                </div>

                {/*====================  End of service page content  ====================*/}

                {/* Brand logo */}
                <BrandLogoSlider background="grey-bg" />

                {/* Footer */}
                {/* <Footer /> */}

                {/* Mobile Menu */}
                {/* <MobileMenu /> */}

            </div>
        )

    }

}
const mapStateToProps = (state) => ({
    loading: state.loading,
    finalData: state.ServicesData
});

const mapDispatchToProps = {
    getServicesData: getServicesData,
};

export default connect(mapStateToProps, mapDispatchToProps)(Services);
const initialTodos = {
    loading: true
};

const reducer = (state = initialTodos, action) => {
    switch (action.type) {
        case 'GET_SERVICES_DATA':
            return {
                ...state
            };
        case 'SERVICES_DATA_RECEIVED':
            return {
                ...state, 
                ServicesData: action.ServicesDataJson,
                loading: false,
            }
        case 'GET_HOME_DATA':
            return {
                ...state
            };
        case 'HOME_DATA_RECEIVED':
            return {
                ...state,
                HomePageData: action.HomeDataJson,
                loading:false
                };
        default:
            return state;
    }
};
export default reducer;
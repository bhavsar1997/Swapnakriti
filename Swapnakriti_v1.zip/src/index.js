// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.scss';
// import App from './App';
// import * as serviceWorker from './serviceWorker';

// ReactDOM.render(<App />, document.getElementById('root'));

// // If you want your app to work offline and load faster, you can change
// // unregister() to register() below. Note this comes with some pitfalls.
// // Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();

import React from 'react';
import createSagaMiddleware from 'redux-saga';
import { render } from 'react-dom';
import './index.scss';
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import reducer from './reducers';
import App from './App';
import rootSaga from './sagas';
import NavBar from './components/NavBar';
import Footer from './components/Footer';
import MobileMenu from './components/MobileMenu';
const sagaMiddleware = createSagaMiddleware();

const store = createStore(
   reducer,
   applyMiddleware(sagaMiddleware)
);
sagaMiddleware.run(rootSaga);
render(
   <Provider store={store}>
      <NavBar />
      <App />
      {/* Footer */}
      <Footer />
      {/* Mobile Menu */}
      <MobileMenu />
   </Provider>,
   document.getElementById('root'),
);
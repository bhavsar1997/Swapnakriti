export const getServicesData = () => ({
    type: 'GET_SERVICES_DATA',
});
export const getHomePageData = () => ({
    type: 'GET_HOME_DATA',
});

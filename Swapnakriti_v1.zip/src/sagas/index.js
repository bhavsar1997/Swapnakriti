import { put, takeLatest, all } from 'redux-saga/effects';

function* fetchServicesData() {
  // const ServicesDataJson = yield fetch('http://localhost:3001/ServicesData')
  const ServicesDataJson = yield fetch('https://swapnakriti-server.herokuapp.com/ServicesData')
        .then(response => response.json(), );    
  yield put({ type: "SERVICES_DATA_RECEIVED", ServicesDataJson });
}

function* fetchHomeData(){
  const HomeDataJson = yield fetch('https://swapnakriti-server.herokuapp.com/HomePageData')
  .then(response => response.json(), );    
yield put({ type: "HOME_DATA_RECEIVED", HomeDataJson });
}

function* actionWatcher() {
     yield takeLatest('GET_SERVICES_DATA', fetchServicesData);
     yield takeLatest('GET_HOME_DATA', fetchHomeData)
}
export default function* rootSaga() {
   yield all([
   actionWatcher(),
   ]);
}